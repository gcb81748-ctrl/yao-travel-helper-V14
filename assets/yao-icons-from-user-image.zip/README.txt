堯的旅遊小助手 icons

請將 assets/icons 整個資料夾複製到你的專案根目錄：
D:\yao-travel-helper\assets\icons\

檔名：
icon-itinerary.png
icon-line.png
icon-sightseeing.png
icon-navigation.png
icon-location.png
icon-nearby-spots.png
icon-nearby-food.png
icon-nearby-shrine.png
icon-settings.png

這組圖示已從你提供的九宮格圖片拆成 9 個獨立 PNG。
